# SOLO LEVELING

A local-first, mobile-friendly personal development PWA.

## Run locally
Open `index.html` in a browser. Core features use browser local storage.

## Host for installation and offline support
For PWA installation and service-worker offline caching, host the files on an HTTPS static host such as GitHub Pages:
1. Create a GitHub repository.
2. Upload `index.html`, `manifest.json`, `sw.js`, and `icon.svg` to the repository root.
3. In repository Settings → Pages, deploy from the main branch and root folder.
4. Open the published HTTPS URL on Android, then use the browser menu → Add to Home screen.

## Notes
- Core app data is stored on the current device. Export a JSON backup in Settings before changing devices or clearing browser data.
- The examiner currently contains a few sample questions; it is a starter app and can be extended with your own question bank.
- Browser notifications are not implemented in this starter version.
- Health and skincare content is educational and intentionally avoids risky DIY remedies, appearance scoring, restrictive diets, or claims of changing facial structure.
